import React from 'react';
import { Calendar, Clock, MapPin, Users, Edit, Trash2 } from 'lucide-react';
import { Meeting } from '../types/Meeting';

interface MeetingCardProps {
  meeting: Meeting;
  onEdit: (meeting: Meeting) => void;
  onDelete: (id: string) => void;
}

const MeetingCard: React.FC<MeetingCardProps> = ({ meeting, onEdit, onDelete }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    return `${hours}:${minutes}`;
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} dakika`;
    } else if (minutes === 60) {
      return '1 saat';
    } else {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      if (remainingMinutes === 0) {
        return `${hours} saat`;
      } else {
        return `${hours} saat ${remainingMinutes} dakika`;
      }
    }
  };

  const getMeetingStatus = () => {
    const now = new Date();
    const meetingDateTime = new Date(`${meeting.date}T${meeting.time}`);
    const endDateTime = new Date(meetingDateTime.getTime() + meeting.duration * 60000);

    if (now < meetingDateTime) {
      return { status: 'upcoming', color: '#28a745', text: 'Yaklaşan' };
    } else if (now >= meetingDateTime && now <= endDateTime) {
      return { status: 'ongoing', color: '#ffc107', text: 'Devam ediyor' };
    } else {
      return { status: 'completed', color: '#6c757d', text: 'Tamamlandı' };
    }
  };

  const meetingStatus = getMeetingStatus();

  return (
    <div className="card meeting-card">
      <div className="meeting-header">
        <div style={{ flex: 1 }}>
          <h3 className="meeting-title">{meeting.title}</h3>
          <div 
            style={{ 
              display: 'inline-block',
              padding: '4px 12px',
              borderRadius: '20px',
              fontSize: '12px',
              fontWeight: '600',
              backgroundColor: meetingStatus.color + '20',
              color: meetingStatus.color,
              marginBottom: '12px'
            }}
          >
            {meetingStatus.text}
          </div>
        </div>
      </div>

      <div className="meeting-meta">
        <div className="meeting-meta-item">
          <Calendar size={16} />
          <span>{formatDate(meeting.date)}</span>
        </div>
        <div className="meeting-meta-item">
          <Clock size={16} />
          <span>{formatTime(meeting.time)} - {formatDuration(meeting.duration)}</span>
        </div>
        <div className="meeting-meta-item">
          <MapPin size={16} />
          <span>{meeting.location}</span>
        </div>
        {meeting.participants.length > 0 && (
          <div className="meeting-meta-item">
            <Users size={16} />
            <span>{meeting.participants.length} katılımcı</span>
          </div>
        )}
      </div>

      {meeting.description && (
        <div className="meeting-description">
          {meeting.description}
        </div>
      )}

      {meeting.participants.length > 0 && (
        <div style={{ marginBottom: '16px' }}>
          <div style={{ fontSize: '14px', fontWeight: '600', color: '#495057', marginBottom: '8px' }}>
            Katılımcılar:
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {meeting.participants.map((participant, index) => (
              <span
                key={index}
                style={{
                  padding: '4px 12px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '16px',
                  fontSize: '14px',
                  color: '#495057',
                  border: '1px solid #dee2e6'
                }}
              >
                {participant}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="meeting-actions">
        <button
          className="btn btn-secondary"
          onClick={() => onEdit(meeting)}
          style={{ fontSize: '14px', padding: '8px 16px' }}
        >
          <Edit size={16} />
          Düzenle
        </button>
        <button
          className="btn btn-danger"
          onClick={() => onDelete(meeting.id)}
          style={{ fontSize: '14px', padding: '8px 16px' }}
        >
          <Trash2 size={16} />
          Sil
        </button>
      </div>
    </div>
  );
};

export default MeetingCard;
