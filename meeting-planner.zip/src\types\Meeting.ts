export interface Meeting {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  duration: number; // dakika cinsinden
  location: string;
  participants: string[];
  createdAt: string;
  updatedAt: string;
}

export interface MeetingFormData {
  title: string;
  description: string;
  date: string;
  time: string;
  duration: number;
  location: string;
  participants: string;
}
