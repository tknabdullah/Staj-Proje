import React, { useState } from 'react';
import { Plus, Calendar, Filter, Search } from 'lucide-react';
import { Meeting } from '../types/Meeting';
import MeetingCard from './MeetingCard';
import MeetingForm from './MeetingForm';

interface MeetingListProps {
  meetings: Meeting[];
  onAddMeeting: (meetingData: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateMeeting: (id: string, meetingData: Partial<Meeting>) => void;
  onDeleteMeeting: (id: string) => void;
}

type FilterType = 'all' | 'today' | 'upcoming' | 'completed';

const MeetingList: React.FC<MeetingListProps> = ({
  meetings,
  onAddMeeting,
  onUpdateMeeting,
  onDeleteMeeting,
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState<Meeting | null>(null);
  const [filter, setFilter] = useState<FilterType>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Toplantıları filtrele
  const getFilteredMeetings = () => {
    let filtered = meetings;

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(meeting =>
        meeting.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.participants.some(p => p.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Durum filtresi
    const now = new Date();
    switch (filter) {
      case 'today':
        const today = now.toISOString().split('T')[0];
        filtered = filtered.filter(meeting => meeting.date === today);
        break;
      case 'upcoming':
        filtered = filtered.filter(meeting => {
          const meetingDateTime = new Date(`${meeting.date}T${meeting.time}`);
          return meetingDateTime > now;
        });
        break;
      case 'completed':
        filtered = filtered.filter(meeting => {
          const meetingDateTime = new Date(`${meeting.date}T${meeting.time}`);
          const endDateTime = new Date(meetingDateTime.getTime() + meeting.duration * 60000);
          return endDateTime < now;
        });
        break;
      default:
        break;
    }

    // Tarihe göre sırala
    return filtered.sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime();
    });
  };

  const filteredMeetings = getFilteredMeetings();

  const handleEdit = (meeting: Meeting) => {
    setEditingMeeting(meeting);
    setIsFormOpen(true);
  };

  const handleFormClose = () => {
    setIsFormOpen(false);
    setEditingMeeting(null);
  };

  const handleFormSubmit = (meetingData: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingMeeting) {
      onUpdateMeeting(editingMeeting.id, meetingData);
    } else {
      onAddMeeting(meetingData);
    }
    handleFormClose();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Bu toplantıyı silmek istediğinizden emin misiniz?')) {
      onDeleteMeeting(id);
    }
  };

  const getFilterCounts = () => {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    return {
      all: meetings.length,
      today: meetings.filter(m => m.date === today).length,
      upcoming: meetings.filter(m => {
        const meetingDateTime = new Date(`${m.date}T${m.time}`);
        return meetingDateTime > now;
      }).length,
      completed: meetings.filter(m => {
        const meetingDateTime = new Date(`${m.date}T${m.time}`);
        const endDateTime = new Date(meetingDateTime.getTime() + m.duration * 60000);
        return endDateTime < now;
      }).length,
    };
  };

  const filterCounts = getFilterCounts();

  return (
    <div>
      {/* Başlık ve Yeni Toplantı Butonu */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '28px', fontWeight: '700', color: 'white', margin: 0 }}>
          Toplantılarım
        </h2>
        <button
          className="btn btn-primary"
          onClick={() => setIsFormOpen(true)}
        >
          <Plus size={20} />
          Yeni Toplantı
        </button>
      </div>

      {/* Arama ve Filtreler */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Arama */}
          <div style={{ position: 'relative', flex: '1', minWidth: '250px' }}>
            <Search size={20} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#6c757d' }} />
            <input
              type="text"
              placeholder="Toplantı ara..."
              className="form-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ paddingLeft: '44px' }}
            />
          </div>

          {/* Filtreler */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {[
              { key: 'all', label: 'Tümü', icon: Calendar },
              { key: 'today', label: 'Bugün', icon: Calendar },
              { key: 'upcoming', label: 'Yaklaşan', icon: Calendar },
              { key: 'completed', label: 'Tamamlanan', icon: Calendar },
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                className={`btn ${filter === key ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setFilter(key as FilterType)}
                style={{ fontSize: '14px', padding: '8px 16px' }}
              >
                <Icon size={16} />
                {label} ({filterCounts[key as FilterType]})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Toplantı Listesi */}
      {filteredMeetings.length === 0 ? (
        <div className="card empty-state">
          <div className="empty-state-icon">📅</div>
          <h3 className="empty-state-title">
            {searchTerm ? 'Arama sonucu bulunamadı' : 'Henüz toplantı yok'}
          </h3>
          <p className="empty-state-text">
            {searchTerm 
              ? 'Arama kriterlerinizi değiştirmeyi deneyin'
              : 'İlk toplantınızı oluşturmak için "Yeni Toplantı" butonuna tıklayın'
            }
          </p>
          {!searchTerm && (
            <button
              className="btn btn-primary"
              onClick={() => setIsFormOpen(true)}
            >
              <Plus size={20} />
              İlk Toplantımı Oluştur
            </button>
          )}
        </div>
      ) : (
        <div style={{ display: 'grid', gap: '20px' }}>
          {filteredMeetings.map((meeting) => (
            <MeetingCard
              key={meeting.id}
              meeting={meeting}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* Toplantı Formu Modal */}
      <MeetingForm
        isOpen={isFormOpen}
        onClose={handleFormClose}
        onSubmit={handleFormSubmit}
        initialData={editingMeeting}
        title={editingMeeting ? 'Toplantı Düzenle' : 'Yeni Toplantı Oluştur'}
      />
    </div>
  );
};

export default MeetingList;
