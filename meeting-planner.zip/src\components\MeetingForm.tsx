import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Meeting, MeetingFormData } from '../types/Meeting';

interface MeetingFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (meetingData: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt'>) => void;
  initialData?: Meeting | null;
  title: string;
}

const MeetingForm: React.FC<MeetingFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  title
}) => {
  const [formData, setFormData] = useState<MeetingFormData>({
    title: '',
    description: '',
    date: '',
    time: '',
    duration: 60,
    location: '',
    participants: '',
  });

  const [errors, setErrors] = useState<Partial<MeetingFormData>>({});

  // Form verilerini başlat
  useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title,
        description: initialData.description,
        date: initialData.date,
        time: initialData.time,
        duration: initialData.duration,
        location: initialData.location,
        participants: initialData.participants.join(', '),
      });
    } else {
      // Yeni toplantı için bugünün tarihini varsayılan olarak ayarla
      const today = new Date().toISOString().split('T')[0];
      setFormData({
        title: '',
        description: '',
        date: today,
        time: '',
        duration: 60,
        location: '',
        participants: '',
      });
    }
    setErrors({});
  }, [initialData, isOpen]);

  // Form validasyonu
  const validateForm = (): boolean => {
    const newErrors: Partial<MeetingFormData> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Toplantı başlığı gereklidir';
    }

    if (!formData.date) {
      newErrors.date = 'Tarih gereklidir';
    } else {
      const selectedDate = new Date(formData.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        newErrors.date = 'Geçmiş bir tarih seçemezsiniz';
      }
    }

    if (!formData.time) {
      newErrors.time = 'Saat gereklidir';
    }

    if (formData.duration < 15 || formData.duration > 480) {
      newErrors.duration = 'Süre 15-480 dakika arasında olmalıdır';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Konum gereklidir';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Form gönderimi
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const meetingData = {
      title: formData.title.trim(),
      description: formData.description.trim(),
      date: formData.date,
      time: formData.time,
      duration: formData.duration,
      location: formData.location.trim(),
      participants: formData.participants
        .split(',')
        .map(p => p.trim())
        .filter(p => p.length > 0),
    };

    onSubmit(meetingData);
    onClose();
  };

  // Input değişikliklerini handle et
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'duration' ? parseInt(value) || 0 : value,
    }));

    // Hata temizle
    if (errors[name as keyof MeetingFormData]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined,
      }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">{title}</h2>
          <button className="modal-close" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="title">
              Toplantı Başlığı *
            </label>
            <input
              type="text"
              id="title"
              name="title"
              className="form-input"
              value={formData.title}
              onChange={handleInputChange}
              placeholder="Toplantı başlığını girin"
            />
            {errors.title && <div style={{ color: '#dc3545', fontSize: '14px', marginTop: '4px' }}>{errors.title}</div>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="description">
              Açıklama
            </label>
            <textarea
              id="description"
              name="description"
              className="form-input form-textarea"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Toplantı açıklamasını girin"
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div className="form-group">
              <label className="form-label" htmlFor="date">
                Tarih *
              </label>
              <input
                type="date"
                id="date"
                name="date"
                className="form-input"
                value={formData.date}
                onChange={handleInputChange}
              />
              {errors.date && <div style={{ color: '#dc3545', fontSize: '14px', marginTop: '4px' }}>{errors.date}</div>}
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="time">
                Saat *
              </label>
              <input
                type="time"
                id="time"
                name="time"
                className="form-input"
                value={formData.time}
                onChange={handleInputChange}
              />
              {errors.time && <div style={{ color: '#dc3545', fontSize: '14px', marginTop: '4px' }}>{errors.time}</div>}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="duration">
              Süre (dakika) *
            </label>
            <select
              id="duration"
              name="duration"
              className="form-input"
              value={formData.duration}
              onChange={handleInputChange}
            >
              <option value={15}>15 dakika</option>
              <option value={30}>30 dakika</option>
              <option value={45}>45 dakika</option>
              <option value={60}>1 saat</option>
              <option value={90}>1.5 saat</option>
              <option value={120}>2 saat</option>
              <option value={180}>3 saat</option>
              <option value={240}>4 saat</option>
              <option value={480}>8 saat</option>
            </select>
            {errors.duration && <div style={{ color: '#dc3545', fontSize: '14px', marginTop: '4px' }}>{errors.duration}</div>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="location">
              Konum *
            </label>
            <input
              type="text"
              id="location"
              name="location"
              className="form-input"
              value={formData.location}
              onChange={handleInputChange}
              placeholder="Toplantı konumunu girin"
            />
            {errors.location && <div style={{ color: '#dc3545', fontSize: '14px', marginTop: '4px' }}>{errors.location}</div>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="participants">
              Katılımcılar
            </label>
            <input
              type="text"
              id="participants"
              name="participants"
              className="form-input"
              value={formData.participants}
              onChange={handleInputChange}
              placeholder="Katılımcıları virgülle ayırarak girin"
            />
            <div style={{ fontSize: '14px', color: '#6c757d', marginTop: '4px' }}>
              Örnek: Ahmet Yılmaz, Ayşe Demir, Mehmet Kaya
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '24px' }}>
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              İptal
            </button>
            <button type="submit" className="btn btn-primary">
              {initialData ? 'Güncelle' : 'Kaydet'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MeetingForm;
