import { useState, useEffect } from 'react';
import { Meeting } from '../types/Meeting';

const STORAGE_KEY = 'meeting-planner-meetings';

export const useMeetings = () => {
  const [meetings, setMeetings] = useState<Meeting[]>([]);

  // Local storage'dan toplantıları yükle
  useEffect(() => {
    const savedMeetings = localStorage.getItem(STORAGE_KEY);
    if (savedMeetings) {
      try {
        setMeetings(JSON.parse(savedMeetings));
      } catch (error) {
        console.error('Toplantılar yüklenirken hata oluştu:', error);
      }
    }
  }, []);

  // Toplantıları local storage'a kaydet
  const saveMeetings = (newMeetings: Meeting[]) => {
    setMeetings(newMeetings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newMeetings));
  };

  // Yeni toplantı ekle
  const addMeeting = (meetingData: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newMeeting: Meeting = {
      ...meetingData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    const updatedMeetings = [...meetings, newMeeting];
    saveMeetings(updatedMeetings);
    return newMeeting;
  };

  // Toplantı güncelle
  const updateMeeting = (id: string, meetingData: Partial<Meeting>) => {
    const updatedMeetings = meetings.map(meeting => 
      meeting.id === id 
        ? { ...meeting, ...meetingData, updatedAt: new Date().toISOString() }
        : meeting
    );
    saveMeetings(updatedMeetings);
  };

  // Toplantı sil
  const deleteMeeting = (id: string) => {
    const updatedMeetings = meetings.filter(meeting => meeting.id !== id);
    saveMeetings(updatedMeetings);
  };

  // Toplantı getir
  const getMeeting = (id: string) => {
    return meetings.find(meeting => meeting.id === id);
  };

  // Tarihe göre sıralı toplantılar
  const getSortedMeetings = () => {
    return [...meetings].sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime();
    });
  };

  // Bugünkü toplantılar
  const getTodaysMeetings = () => {
    const today = new Date().toISOString().split('T')[0];
    return meetings.filter(meeting => meeting.date === today);
  };

  // Gelecek toplantılar
  const getUpcomingMeetings = () => {
    const now = new Date();
    return meetings.filter(meeting => {
      const meetingDateTime = new Date(`${meeting.date}T${meeting.time}`);
      return meetingDateTime > now;
    });
  };

  return {
    meetings,
    addMeeting,
    updateMeeting,
    deleteMeeting,
    getMeeting,
    getSortedMeetings,
    getTodaysMeetings,
    getUpcomingMeetings,
  };
};
