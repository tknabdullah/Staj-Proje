import React from 'react';
import { Calendar, Users, Clock, TrendingUp } from 'lucide-react';
import { useMeetings } from './hooks/useMeetings';
import MeetingList from './components/MeetingList';

const App: React.FC = () => {
  const {
    meetings,
    addMeeting,
    updateMeeting,
    deleteMeeting,
    getTodaysMeetings,
    getUpcomingMeetings,
  } = useMeetings();

  const todaysMeetings = getTodaysMeetings();
  const upcomingMeetings = getUpcomingMeetings();

  const getStats = () => {
    const now = new Date();
    const thisWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    const thisWeekMeetings = meetings.filter(meeting => {
      const meetingDate = new Date(meeting.date);
      return meetingDate >= now && meetingDate <= thisWeek;
    });

    const totalDuration = meetings.reduce((total, meeting) => total + meeting.duration, 0);
    const totalParticipants = meetings.reduce((total, meeting) => total + meeting.participants.length, 0);

    return {
      total: meetings.length,
      thisWeek: thisWeekMeetings.length,
      totalDuration: Math.round(totalDuration / 60), // saat cinsinden
      totalParticipants,
    };
  };

  const stats = getStats();

  return (
    <div className="container">
      {/* Header */}
      <div className="header">
        <h1>📅 Toplantı Planlayıcı</h1>
        <p>Toplantılarınızı kolayca planlayın ve yönetin</p>
      </div>

      {/* İstatistikler */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '40px' }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <Calendar size={32} style={{ color: '#667eea', marginBottom: '12px' }} />
          <h3 style={{ fontSize: '24px', fontWeight: '700', color: '#2c3e50', marginBottom: '4px' }}>
            {stats.total}
          </h3>
          <p style={{ color: '#6c757d', margin: 0 }}>Toplam Toplantı</p>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <TrendingUp size={32} style={{ color: '#28a745', marginBottom: '12px' }} />
          <h3 style={{ fontSize: '24px', fontWeight: '700', color: '#2c3e50', marginBottom: '4px' }}>
            {stats.thisWeek}
          </h3>
          <p style={{ color: '#6c757d', margin: 0 }}>Bu Hafta</p>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <Clock size={32} style={{ color: '#ffc107', marginBottom: '12px' }} />
          <h3 style={{ fontSize: '24px', fontWeight: '700', color: '#2c3e50', marginBottom: '4px' }}>
            {stats.totalDuration}h
          </h3>
          <p style={{ color: '#6c757d', margin: 0 }}>Toplam Süre</p>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <Users size={32} style={{ color: '#dc3545', marginBottom: '12px' }} />
          <h3 style={{ fontSize: '24px', fontWeight: '700', color: '#2c3e50', marginBottom: '4px' }}>
            {stats.totalParticipants}
          </h3>
          <p style={{ color: '#6c757d', margin: 0 }}>Toplam Katılımcı</p>
        </div>
      </div>

      {/* Hızlı Bilgiler */}
      {(todaysMeetings.length > 0 || upcomingMeetings.length > 0) && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          {todaysMeetings.length > 0 && (
            <div className="card" style={{ borderLeft: '4px solid #28a745' }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#2c3e50', marginBottom: '12px' }}>
                📅 Bugünkü Toplantılar ({todaysMeetings.length})
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {todaysMeetings.slice(0, 3).map(meeting => (
                  <div key={meeting.id} style={{ fontSize: '14px', color: '#495057' }}>
                    <strong>{meeting.time}</strong> - {meeting.title}
                  </div>
                ))}
                {todaysMeetings.length > 3 && (
                  <div style={{ fontSize: '14px', color: '#6c757d', fontStyle: 'italic' }}>
                    +{todaysMeetings.length - 3} toplantı daha...
                  </div>
                )}
              </div>
            </div>
          )}

          {upcomingMeetings.length > 0 && (
            <div className="card" style={{ borderLeft: '4px solid #667eea' }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#2c3e50', marginBottom: '12px' }}>
                ⏰ Yaklaşan Toplantılar ({upcomingMeetings.length})
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {upcomingMeetings.slice(0, 3).map(meeting => (
                  <div key={meeting.id} style={{ fontSize: '14px', color: '#495057' }}>
                    <strong>{new Date(meeting.date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })}</strong> - {meeting.title}
                  </div>
                ))}
                {upcomingMeetings.length > 3 && (
                  <div style={{ fontSize: '14px', color: '#6c757d', fontStyle: 'italic' }}>
                    +{upcomingMeetings.length - 3} toplantı daha...
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Ana Toplantı Listesi */}
      <MeetingList
        meetings={meetings}
        onAddMeeting={addMeeting}
        onUpdateMeeting={updateMeeting}
        onDeleteMeeting={deleteMeeting}
      />
    </div>
  );
};

export default App;
